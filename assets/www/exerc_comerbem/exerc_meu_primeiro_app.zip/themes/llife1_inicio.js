var db;
var jQT = $.jQTouch({
	icon: 'kilo.png',
	statusBar: 'black'
});

